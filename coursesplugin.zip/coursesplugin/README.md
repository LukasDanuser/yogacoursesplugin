# CoursesPlugin

This plugin only works with WooCommerce

To make this plugin work you also need following plugins:
"Insert PHP Code Snippet" by xyzscripts.com
"Thanks Redirect for WooCommerce" by Nitin Prakash
"WooCommerce" by Automattic
"WooCommerce Payments" by Automattic
"UsersWP" by AyeCode

In "Thanks Redirect for WooCommerce" you need to set the thanks redirect to:
"<< yourURL >>/thanks"

In "UsersWP" go to:
settings>>Form Builder>>Form Options: set "Registration Action" to "Auto approve + Auto Login" AND "Redirect Page" to "Checkout"

With this plugin you can sell 2 memberships (half year or full year).
You also can create and sell online courses.
